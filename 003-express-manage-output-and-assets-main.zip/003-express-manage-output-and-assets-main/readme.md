# Excercise
1 - Add a /test route, and load a test.ejs file
2 - Make a link on index.ejs to go to /test and viceversa using "a" HTML tag